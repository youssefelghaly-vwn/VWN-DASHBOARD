<?php

namespace App\Dashboard\Controllers;

use App\Dashboard\Models\Chart;
use App\Dashboard\Models\Dashboard;
use App\Dashboard\Services\DashboardData;
use App\Http\Controllers\Controller;
use App\Support\FilterOperators;
use Illuminate\Http\Request;

class ChartController extends Controller
{
    private const TYPES = [
        'bar', 'horizontalBar', 'stackedBar', 'line', 'area',
        'pie', 'doughnut', 'polarArea', 'radar', 'scatter', 'bubble',
    ];

    private const AGGS = ['count', 'sum', 'avg', 'min', 'max'];

    public function store(Request $request, Dashboard $dashboard, DashboardData $data)
    {
        $chart = Chart::create($this->validated($request) + [
            'user_id' => $request->user()->id,
            'dashboard_id' => $dashboard->id,
            'position' => (int) Chart::where('dashboard_id', $dashboard->id)->max('position') + 1,
        ]);

        return response()->json($data->buildChart($chart), 201);
    }

    public function update(Request $request, Chart $chart, DashboardData $data)
    {
        $chart->update($this->validated($request));

        return response()->json($data->buildChart($chart->fresh()));
    }

    public function destroy(Chart $chart)
    {
        $chart->delete();

        return response()->noContent();
    }

    private function validated(Request $request): array
    {
        return $request->validate([
            'title' => ['required', 'string', 'max:120'],
            'type' => ['required', 'in:'.implode(',', self::TYPES)],
            'integration_id' => ['nullable', 'integer', 'exists:integrations,id'],
            'section_id' => ['nullable', 'integer', 'exists:dashboard_sections,id'],
            'sheet' => ['required', 'string'],
            'label_column' => ['required', 'string'],
            'aggregate' => ['required', 'in:'.implode(',', self::AGGS)],
            'limit' => ['required', 'integer', 'min:1', 'max:50'],
            'width' => ['nullable', 'in:full,twothirds,half,third'],
            'height' => ['nullable', 'integer', 'min:160', 'max:900'],
            'filters' => ['nullable', 'array'],
            'filters.*.column' => ['nullable', 'string'],
            'filters.*.operator' => ['nullable', 'in:'.implode(',', FilterOperators::keys())],
            'filters.*.value' => ['nullable', 'string', 'max:255'],
            'series' => ['required', 'array', 'min:1'],
            'series.*.integration_id' => ['nullable', 'integer', 'exists:integrations,id'],
            'series.*.sheet' => ['required', 'string'],
            'series.*.column' => ['nullable', 'string'],
            'series.*.agg' => ['required', 'in:'.implode(',', self::AGGS)],
            'series.*.label' => ['required', 'string', 'max:60'],
            'series.*.color' => ['nullable', 'string', 'max:9'],
        ]);
    }
}
